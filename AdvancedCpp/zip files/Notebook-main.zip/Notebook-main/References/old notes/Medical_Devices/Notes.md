Diagnostics


Day 1
QMS
Medical Devices Introduction
ISO 13485
Standards requirement
21CFSR
EU-MDR
https://www.iso.org/obp/ui/#iso:std:iso:13485:ed-3:v1:en


Medical Device Regulation 2017/745
Medical devices are classified based on the Risk
Class I,II,II,III
Design Control
Verification and Validation
DHF - design document
DMR  - procedure and specification
DHR - production hsitory

Risk Management
 
 
 
 Below are the links of the videos I presented today.


    https://www.youtube.com/watch?v=ylgwrGevLuw&feature=youtu.be
    https://www.youtube.com/embed/uIgt4lJf0qs?rel=0

 

Before tomorrows session

    Research on
        Microfluidics
        Voice of Customer
        Trends in Medical devices
    Go through below
        https://www.youtube.com/watch?v=aF_Hy-cK7OE&feature=youtu.be  
        https://www.youtube.com/embed/EF1SDdvc5kY?rel=0
        https://www.youtube.com/embed/F765Zc5-k34?rel=0
        https://www.youtube.com/embed/h79JOIGbAXw?rel=0
