#include<stdio.h>
#include<math.h>
#define PI 22.0/7.0


int main() {
  int count,n; //int x
  printf("enter a val\n");
  scanf("%d",&n);


  for(count=1;count<=100;count++) {
    printf("Hello,line no.%d\n",i);


  return 0;
}

