# Outline

## Makefiles
* Significance of Makefiles for intelligent build[click here](intro.md)
* Simple Makefile [click here](tuto1/README.md)
* Using special variables [click here](tuto2)
* Implicit rules [click here](tuto3)
* Pattern based rules [click here](tuto4)

# References
    https://cboard.cprogramming.com/c-programming/150667-makefile-problem;-create-obj-file-outside-src-folder.html