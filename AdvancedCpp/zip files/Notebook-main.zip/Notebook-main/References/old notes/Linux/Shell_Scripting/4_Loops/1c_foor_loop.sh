#!/bin/bash
: '
This is an example to loop through the files in the directory
'
for f in *
 do
  echo "File -> ${f}"
done