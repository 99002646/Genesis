#!/bin/sh

#This is a infinite loop example
while :
do
  echo "Type something in (CTRL + C to quit)"
  read INPUT
  echo "You typed: $INPUT"
done