#!/bin/bash

STRING="this is a string"
POS=1
LEN=3
echo ${STRING:$POS:$LEN}