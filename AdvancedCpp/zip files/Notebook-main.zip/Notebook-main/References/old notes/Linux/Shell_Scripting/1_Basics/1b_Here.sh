#!/bin/bash
echo "Welcome"
date
cal
bc << HERE
2+3
4*5
9-2
HERE

rev << STRINGS
abcd
pqrs
1234
STRINGS
echo "thank you"
