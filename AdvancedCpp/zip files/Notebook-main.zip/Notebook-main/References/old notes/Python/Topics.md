# Study Topics

* Object Oriented Programming
* Class
    - intance methods
        - constructor
        - Dictonary
        - instance variable
    - class method
        - class variable
    - static methods
    - magic methods
        - Operator Overloading
        - Representation class         # Completed
        - [callable](https://www.journaldev.com/22761/python-callable-__call__)
        - destructor
        - [decorator](https://www.programiz.com/python-programming/decorator)
    - inheritance
         - super
    - MRO(Method resolution order)
    - private
    

* [Regular expressions](https://www.w3schools.com/python/python_regex.asp)
    - Basics
    - Notations
    - Groups
    - Recersive Search (findall)
    - substitute
    - raw string representation

* Multi Thread
    - Tasks,process,Multiprogramming,Multitask : process scheduling,Swap area
    - functions
    - callable

* Syncronization

* Network Programming (Socket Programming)
* exception handling
* object serialization
* os ,cis ,platform modules

# Stepin revision
* file handling