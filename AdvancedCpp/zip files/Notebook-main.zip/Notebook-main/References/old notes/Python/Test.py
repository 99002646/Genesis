import re
import os
import functools 

os.system("clear")
