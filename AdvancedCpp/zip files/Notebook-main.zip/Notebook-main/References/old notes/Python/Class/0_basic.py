# Basic Class template and Object declaration

class test():
    pass       #Empty Class 

#<objName> = <ClassName>()
t1 = test()  #object declaration

print(type(t1))   #object types
