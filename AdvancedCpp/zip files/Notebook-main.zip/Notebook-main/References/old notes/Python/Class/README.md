# Class

* [Basic Syntax](0_basic.py)
* [Dictonary](1_dict.py)
* [intance method](2_intanceMethod.py)
* [Class method](3_classMethod.py)
* [static method](4_staticMethod.py)
* [Magic method](5_magicMethod.py)
* [call method]

6_objRep
7_callable

constructor


class method
class variable
static methods
magic methods
        - Operator Overloading
        - Representation class         # Completed
        - callable
        - destructor
        - decorator
    - inheritance
         - super
    - MRO(Method resolution order)
    - private