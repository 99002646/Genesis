# Notes

IndexError and all errors are class returns obj of IndexError

# Situations
* basically undesired cases
* Trying to access file which doest exit will lead to an error in read mode - file exception
* accessing list element beyond its range  
* accesing by wrong error