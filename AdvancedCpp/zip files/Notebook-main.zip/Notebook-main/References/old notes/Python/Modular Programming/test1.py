import os
os.system("clear")

#from moduleName import *       // this is all defined in this file

from mathOP import *

print(add(2,6))
print(sub(5,5))