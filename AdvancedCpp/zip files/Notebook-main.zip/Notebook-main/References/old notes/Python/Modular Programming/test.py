import os
os.system("clear")

import mathOP

det = dir()
print(det)

print(mathOP.__file__)

for i in range(len(det)):
    print(det[i])

print(mathOP.add(2,6))

print(mathOP.sub(5,5))

'''
To Call functions of Module
moduleName.functionName


https://techwithtim.net/tutorials/python-programming/beginner-python-tutorials/introduction-to-modular-programming/
'''