
# Activity

## Team
1. Major defects and recalls in Medical Devices
    - incident 
    - cause (why?)
    - impact (effects)
    - outcome (Loss )

2. Understanding of UML vs SysMl
    - Explain with the example

3.  Analyse and Understanding of Agile  
    - Manifesto , Principles, Roles, Ceremonies, Artifacts, Tools
    - Next Few Days - Run agile method by rotating the roles, Ceremonies etc
    - Team organize

4. Product of Simple Calculator
    - Vmodel
    - Agile Model

5. Tools summary Tool Chain of Differnt Models

## Induvidual 
1. V Model for Product(Beverage Dispenser by)
    1. Tilte and Introduction 
    2. Research(Outcome Features with References)
    3. About Product
    4. SWOT Analysis
    5. Requirements(id,Des)
        - High level 
        - Low level
    6. Design
        - System Design
            - Structure 
            - Behaviaral
        - Unit Design
             - Structure 
            - Behaviaral
    7. Test Plan
        - Intetgrated and Unit Test Plan

2. Vmodel for Mini Project with Implementation
    docuement the Delta changes and Adapt the Changes in the Micro Project of c++
    - Git Setup and Badges of C++
    - Issues Screen Shot
    - Code Quality
    - Unit Test FrameWork
    - Failure Test Cases 

3. Aigle Model adaptation of Product()
    - Product Backlog(Showcase Artifacts)
        - themes
        - epic
        - user stroies


## Wishlist
1. Results Graphical Representaion
2. References
3. Traceability
4. Chronological Order
5. 

# Topics
* V model
* Agile Model
* Unit testing
* Singular Point
* MC ,BC
* IBM DOORS
* Star UML
* Visual Paradie
* Enterprise Architect
* Microsoft Visio
* Magic Draw
Selinium
Test Plan
* LDRA 
* Parasoft

CI/CD
* Git 

# Notes
## SDLC Procdedure 
1. Introduction
    
2. Research(Aging vs Costing)
    - ageing (product features for different years)
        - costing (price related parameters)

3. About Product 
    - Define Product

4. SWOT Analysis

5. Requirements
    * ID and Disc
    * High Level - Features
    * Low level to acceess that functional

6. Design
    * UML Diagrams
        - Structural ()
        - Behaviaral (Componet level,sequence diagram)

7. Test Plan(Requirement,Scenario,Boundary Conditions)
    - Integration Test PLan 
        * test id
        * descriptiom
        * expected input
        * expected output
    - Unit Test Plan
    - high level to low level traceability

## Challanges 
* Power Backup
* Traceability 