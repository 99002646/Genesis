# Operator Oveloading

## Concept Checking / Discussion Points
* Need for operator overloading
* Time examples
* Overloading binary operators  : t1 + t2, t1 + 10 [code](example1.cxx)
* Overloading unary operators : pre, post increment [code](example2.cxx)
* Overloading ==, < , > [code](example3.cxx)
* Overloading =  [code](example4.cxx)
* Overloading as friend [code](example5.cxx)
* Overloading <<, >> [code](example6.cxx)

> [Click Here](Notes.md) for notes
