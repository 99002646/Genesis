#include"fun.h"
int main() {
  int a,b,c,d;
  a=10;
  b=20;
  c=sum(a,b);
  d=square(a);
  //print c,d
  return 0;
}