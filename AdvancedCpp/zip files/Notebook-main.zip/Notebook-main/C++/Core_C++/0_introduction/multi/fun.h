#ifndef __FUN_H
#define __FUN_H

int sum(int,int);
int square(int);

#endif