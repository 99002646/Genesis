#include<iostream>

int main() {
 std::cout << "Hello World\n";
 std::cout << "Thank You" << std::endl;
 return 0;
}


