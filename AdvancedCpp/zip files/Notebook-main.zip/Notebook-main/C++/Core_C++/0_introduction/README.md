# Introduction

## Concept Checking / Discussion Points
* Introduction to C++
* History & Standards
* Compilers & IDEs
* Simple Hello World Program [example](1_hello.cxx)
* console i/o operations [example](2_sumdemo.cxx)
* Phases of development [example](multi)
* Types of errors
* Memory layout of a loaded process [example](3_layout.cxx)
* Learning Resources

> [Click Here](Notes.md) for Notes
