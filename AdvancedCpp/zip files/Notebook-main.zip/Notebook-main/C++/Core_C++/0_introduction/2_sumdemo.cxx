#include<iostream>

int main() {
    //std::cout << "Hello World\n";
    int a, b, c;
    std::cout << "Enter two numbers\n";
    std::cin >> a >> b;
    c = a + b;
    std::cout << "sum is " << c << "\n";
    return 0;
}
