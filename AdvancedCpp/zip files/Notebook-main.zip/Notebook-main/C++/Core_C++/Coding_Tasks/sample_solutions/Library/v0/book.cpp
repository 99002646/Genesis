#include "book.h"
std::ostream& operator<< (std::ostream& rout, const Book& rb) {
  //print all members using rb
  return rout;
}