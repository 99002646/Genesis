#include<iostream>
class Simple {
//members
};
void test() {
//some code
}
int xvar;

int main() {
    int xvar;
    std::cout << ::xvar << "\n";

}
