int yvar;
namespace n1 {
  int zvar=100;
};
namespace {
class Simple {
  // members
};
void test() {
  // some code
}
int xvar;
}; // namespace

int main() {
  Simple s1;
  ++xvar;
  test();
}
