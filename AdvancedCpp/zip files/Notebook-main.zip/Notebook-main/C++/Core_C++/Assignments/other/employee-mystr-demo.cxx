class Employee {
  int empid;
  MyString ename;
  int age;
  double exp;
  public:
  //suitable ctors - default, param, copy
  //display
}
int main() {

}
