/*
* Employee -- suitable data
           -- suitable ctror
           -- pure virtual : payroll, appraisal
* Engineer -- inherit employee
           -- add any data & operations
           -- override virtual functions
* Traineed/Manager -- same as above
* test plan with dyn demo
*/
