int main() {
  Fraction f1(2,3);
  Fraction f2(3,4);
  // f1 + f2
  // f1 - f2
  // f1 * f2
  // f1 + 5         // 5 + 2/3
  // f1 * 2
  // f1 == f2
  // std::cout << f1 
  return 0;
}
