int main() {
  MyArray<int> a1(10);
  //fill array
  //display
  //print a1.reverse();
  //print a1.average();
  //print a1.min(), a1.max()
  //a1.sort()
  //a1.search(key), a1.count(val)
}
  
