int main() {
 Distance d1(5,10);
 Distance d2(1,4);
 // d1 + d2
 // d1 + 8
 // d1 - d2
 // ++d1
 // d1 == d2, d1 < d2, d1 > d2
 // cout << d1
 return 0;
}
