int main() {
/** TODO : Overload other operators in MyString class
    MyString s1("abcd");
    s3 = s1 + s2;
    s4 = s1 + "xyz";
    s3 == s2;
    s1+="1234";
    s2 = "hello";
    s1 < s2
    s1 > s1
    std::cout << s1;
    std::cin >> s2;
*/
}
