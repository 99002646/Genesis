//TODO: Implement mobile billing solution in suitable file hierarchy
//      with Customer, Prepaid, Postpaid classes
int main() {
  //Demonstrate runtime polymorphism
  //RTTI, casting operators
}
