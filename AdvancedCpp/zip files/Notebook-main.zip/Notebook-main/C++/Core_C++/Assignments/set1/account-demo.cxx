/*
* Account -- suitable data members
          -- suitable ctors
          -- pure virtual : debit, credit
          -- any other normal
* SavingsAccount -- additional data members
          -- suitable ctors
          -- override virtual functions
          -- any additional functions
* CreditAccount -- same as Savings
* main - test plan with dynamic binding
*/
