#ifndef __FUN_H
#define __FUN_H

#ifdef __cpluplus
extern "C" {
#endif

  double square(double);

#ifdef __cpluplus
}
#endif

#endif