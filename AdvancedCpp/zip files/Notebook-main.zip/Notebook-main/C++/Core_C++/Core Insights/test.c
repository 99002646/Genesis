#include "fun.h"

double square(double x) {
  return x * x;
}
void test() {
  int c = sum(10,20);
}
