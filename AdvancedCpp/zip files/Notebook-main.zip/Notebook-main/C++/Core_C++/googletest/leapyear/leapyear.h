#ifndef __LEAPYEAR_H_
#define __LEAPYEAR_H_

int IsLeapYear(int);

#endif

