#ifndef __TRIANGLE_H_
#define __TRIANGLE_H_

int TypeOfTriangle(int, int, int);

#endif

