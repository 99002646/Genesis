#ifndef __BOOK_H
#define __BOOK_H

class Book {
  int m_id;
  std::string m_title;
  std::string m_author;
  std::string m_publisher;
  double m_price;
  int m_pages;
  public:
  //TODO: default ctor
  //TODO: param ctor with 6 args
  //TODO: param ctor with few args
  //TODO: display
  //TODO: get functions
};

#endif
