## Actions
    git actions are set in the ".github/workflows" folder in the repositary
* [Unit Test by Cmake](.github/workflows/unitTest_Cmake.yml)


## Reference Links
* [Git Actions](https://docs.github.com/en/free-pro-team@latest/actions)
* https://www.codeproject.com/Articles/1214409/Learn-YAML-in-five-minutes